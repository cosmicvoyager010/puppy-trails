# Puppy Trails

A small companion-walking PWA, structured in modular layers instead of one monolithic HTML file.

## Structure
- `index.html` — app shell markup only
- `css/` — app.css (layout/components), screens.css (screen system), themes.css (mood backgrounds)
- `js/state.js` — single source of truth (`appState`)
- `js/storage.js` — save/load `appState` via localStorage
- `js/router.js` — shows/hides `.screen` sections
- `js/modules/` — puppy.js, walk.js, world.js (active); voice.js, achievements.js (stubs for later)
- `js/screens/` — home.js (active); discoveries.js, settings.js, developer.js (stubs for later)
- `manifest.json`, `sw.js` — PWA install support

## Status: Version 1 (per roadmap)
Implemented: puppy, walk button, mood system, save system, basic PWA shell.
Not yet implemented (stubs only): GPS walks, discoveries/regions, voice, achievements, developer/debug screen.

## Running locally
Because `js/app.js` uses ES module imports, opening `index.html` directly via
double-click (`file://`) will fail to load the modules in Chrome due to CORS
restrictions on the file protocol. Instead, serve it locally, e.g.:

```
python3 -m http.server 8000
```

then visit `http://localhost:8000/`. It will also work correctly once hosted
on GitHub Pages (served over https).

## Known gaps
- `assets/icons/icon-192.png` and `icon-512.png` referenced by `manifest.json`
  don't exist yet — add real PNGs there for proper install icons / iOS home
  screen icon.
