// storage.js — save/restore appState via localStorage so progress isn't lost on reload.

const STORAGE_KEY = "puppyTrailsState";

export function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.warn("Save failed:", err);
  }
}

export function loadState(state) {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;

    const saved = JSON.parse(raw);
    if (saved.puppy) Object.assign(state.puppy, saved.puppy);
    if (saved.walk) Object.assign(state.walk, saved.walk);
    if (saved.world) Object.assign(state.world, saved.world);

    // Never resume a walk as "in progress" after a reload — always start at rest.
    state.walk.active = false;
  } catch (err) {
    console.warn("Load failed:", err);
  }
}

export function resetState(state) {
  state.puppy.mood = "happy";
  state.puppy.energy = 100;
  state.puppy.bond = 0;
  state.walk.active = false;
  state.walk.steps = 0;
  state.walk.distance = 0;
  state.world.region = "home";
  state.world.mood = "CALM";
  saveState(state);
}
