// state.js — single source of truth for the whole app.
// Nothing else should update the UI directly; everything reads/writes this object.

export const appState = {
  puppy: {
    mood: "happy",   // "happy" | "tired"
    energy: 100,     // 0-100
    bond: 0           // 0-100
  },

  walk: {
    active: false,
    steps: 0,
    distance: 0       // meters (arbitrary unit for now)
  },

  world: {
    region: "home",
    mood: "CALM"       // CALM | BRIGHT | QUIET | MYSTERIOUS
  }
};
