// screens/home.js — binds DOM elements on the home screen and renders appState into them.
// This is the only file that should touch the home screen's DOM directly.

import { appState } from "../state.js";
import { startWalk, stopWalk } from "../modules/walk.js";
import { saveState } from "../storage.js";

let els = {};

export function initHomeScreen() {
  els.puppy = document.getElementById("puppy");
  els.status = document.getElementById("status");
  els.walkBtn = document.getElementById("walkBtn");
  els.stats = document.getElementById("stats");

  els.walkBtn.addEventListener("click", () => {
    if (appState.walk.active) {
      stopWalk();
    } else {
      startWalk();
    }
    renderHome();
    saveState(appState);
  });
}

export function renderHome() {
  const { puppy, walk } = appState;

  els.puppy.classList.toggle("walking", walk.active);
  els.puppy.classList.toggle("tired", puppy.mood === "tired" && !walk.active);

  if (walk.active) {
    els.status.textContent =
      puppy.mood === "tired" ? "Getting tired, but still going..." : "Walking outside...";
  } else {
    els.status.textContent =
      puppy.energy >= 100 ? "Your companion is fully rested." : "Your companion is resting...";
  }

  els.walkBtn.textContent = walk.active ? "Stop Walk" : "Start Walk";
  els.walkBtn.disabled = !walk.active && puppy.energy <= 0;

  els.stats.textContent =
    `Energy: ${puppy.energy} · Bond: ${puppy.bond} · Steps: ${walk.steps} · Distance: ${walk.distance.toFixed(1)}m`;
}
