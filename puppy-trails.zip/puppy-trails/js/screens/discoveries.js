// screens/discoveries.js — Reserved for Version 2 (regions, collectibles). Not wired up yet.

export function initDiscoveriesScreen() {}
