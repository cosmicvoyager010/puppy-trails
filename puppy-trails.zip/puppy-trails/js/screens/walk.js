// screens/walk.js — Reserved for Version 2 (dedicated walk/map screen with GPS).
// The basic walk button lives on the home screen for now; this becomes its
// own screen once GPS/map features are added.

export function initWalkScreen() {}
