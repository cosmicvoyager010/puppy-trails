// screens/settings.js — Reserved (sound, units, reset save). Not wired up yet.

export function initSettingsScreen() {}
