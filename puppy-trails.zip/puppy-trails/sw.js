// sw.js — minimal service worker. Required for "Add to Home Screen" / installability.
// Intentionally simple for now (no caching strategy yet) — improve later per the roadmap.

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  self.clients.claim();
});

self.addEventListener("fetch", () => {
  // No-op passthrough for now.
});
